package com.hunger.saviour.portal.services;

import com.hunger.saviour.portal.dtos.SignUpRequestDTO;
import org.springframework.web.bind.annotation.RequestBody;

public interface UserService {

    String signUp(SignUpRequestDTO signUpRequestDTO);
}
