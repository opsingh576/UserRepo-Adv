package com.client.service.client_service.Proxy;


import com.email.notifaction.service.email_notifaction_service.Entity.EmailRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service")
public interface NotificationClient {

    @PostMapping("/api/notify/email")
    String sendEmail(@RequestBody EmailRequest emailRequest);
}
