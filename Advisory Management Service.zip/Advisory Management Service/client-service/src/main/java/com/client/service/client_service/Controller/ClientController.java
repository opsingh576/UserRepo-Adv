package com.client.service.client_service.Controller;

import com.client.service.client_service.Proxy.NotificationClient;
import com.email.notifaction.service.email_notifaction_service.Entity.EmailRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/client")
public class ClientController {

    @Autowired
    private NotificationClient notificationClient;

    @PostMapping("/trigger-email")
    public ResponseEntity<String> triggerEmail(@RequestBody EmailRequest request) {
        String response = notificationClient.sendEmail(request);
        return ResponseEntity.ok(response);
    }



}
