package com.client.service.client_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
