package com.email.notifaction.service.email_notifaction_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailNotifactionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
