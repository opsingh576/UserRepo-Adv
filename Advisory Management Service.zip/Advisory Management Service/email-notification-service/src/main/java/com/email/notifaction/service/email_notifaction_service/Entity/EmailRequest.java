package com.email.notifaction.service.email_notifaction_service.Entity;

public class EmailRequest {

    private String to;
    private String subject;
    private String body;


}
