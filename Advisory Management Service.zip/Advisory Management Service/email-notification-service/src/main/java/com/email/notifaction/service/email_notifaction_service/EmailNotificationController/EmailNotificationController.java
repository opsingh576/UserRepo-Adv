package com.email.notifaction.service.email_notifaction_service.EmailNotificationController;

import com.email.notifaction.service.email_notifaction_service.EmailNotifactionService.SendEmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailNotificationController {

    @Autowired
    private SendEmailService sendEmailService;

    @GetMapping("sendEmail")
    public String sendEmail() {

        sendEmailService.sendEmail("opsing576@gmail.com", "Test Body", "Test Subject");
        return "send successfully";

    }

}

/*
    @Autowired
    private JavaMailSender mailSender;

    @PostMapping("/email")
    public ResponseEntity<String> sendEmail(@RequestBody EmailRequest request) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(request.getTo());
        message.setSubject(request.getSubject());
        message.setText(request.getBody());

        mailSender.send(message);

        return ResponseEntity.ok("Email sent successfully!");

    }
*/


