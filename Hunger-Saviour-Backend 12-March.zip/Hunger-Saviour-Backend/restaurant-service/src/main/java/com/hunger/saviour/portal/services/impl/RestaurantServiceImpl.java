package com.hunger.saviour.portal.services.impl;

import com.hunger.saviour.portal.dtos.RestaurantDTO;
import com.hunger.saviour.portal.dtos.RestaurantMenuDTO;
import com.hunger.saviour.portal.entities.RestaurantEntity;
import com.hunger.saviour.portal.entities.RestaurantMenuEntity;
import com.hunger.saviour.portal.repositories.RestaurantRepository;
import com.hunger.saviour.portal.services.RestaurantService;
import com.hunger.saviour.portal.utilities.RestaurantMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RestaurantServiceImpl implements RestaurantService {

    private final RestaurantRepository restaurantRepository;

    @Override
    public Page<RestaurantEntity> getRestaurants(int pageNumber, int pageSize) {
        Page<RestaurantEntity> restaurants = this.restaurantRepository
                .findAll(PageRequest.of(pageNumber, pageSize));
        return restaurants;
    }

    @Override
    public List<RestaurantDTO> getAllRestaurants() {
        List<RestaurantEntity> restaurantEntities = restaurantRepository.findAll();
        return restaurantEntities.stream().map(RestaurantMapper.INSTANCE::entityToDTO).toList();
    }

    @Override
    public RestaurantDTO getRestaurantById(Integer restaurantId) throws Exception {
      RestaurantEntity restaurantEntity = restaurantRepository
              .findById(restaurantId)
              .orElseThrow(() -> new Exception("Restaurant not found with id: "+ restaurantId));
      return RestaurantMapper.INSTANCE.entityToDTO(restaurantEntity);
    }
}
