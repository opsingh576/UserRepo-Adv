package com.hunger.saviour.portal.apis;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hunger.saviour.portal.dtos.RestaurantDTO;
import com.hunger.saviour.portal.entities.RestaurantEntity;
import com.hunger.saviour.portal.repositories.RestaurantRepository;
import com.hunger.saviour.portal.services.RestaurantService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.data.domain.Page;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

@RestController
@RequestMapping("/restaurants")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class RestaurantAPI {

    private final ObjectMapper objectMapper;
    private final RestaurantService restaurantService;

    @GetMapping("/{pageNumber}/{pageSize}")
    public Page<RestaurantEntity> getRestaurants(@PathVariable Integer pageNumber, @PathVariable Integer pageSize){
        return this.restaurantService.getRestaurants(pageNumber, pageSize);
    }

    @GetMapping
    public List<RestaurantDTO> getAllRestaurants(){
        return this.restaurantService.getAllRestaurants();
    }

    private final ResourceLoader resourceLoader;
    private final RestaurantRepository restaurantRepository;
    @GetMapping("/load")
    public String loadRestaurantsInDatabase()throws Exception{
        Resource resource = resourceLoader.getResource("classpath:"+"restaurants.json");
        try(InputStreamReader reader = new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8)){
            String data = FileCopyUtils.copyToString(reader);
            List<RestaurantEntity> restaurantEntities = objectMapper.readValue(data, new TypeReference<List<RestaurantEntity>>() {});
            this.restaurantRepository.saveAll(restaurantEntities);
        }
        return "Records Inserted";
    }

    @GetMapping("/{restaurantId}")
    public RestaurantDTO getRestaurantById(@PathVariable Integer restaurantId) throws Exception {
        return this.restaurantService.getRestaurantById(restaurantId);
    }

}
