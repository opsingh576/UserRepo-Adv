## openssl genrsa -out keypair.pem 2048
- This command generates a 2048-bit RSA private key(cryptographic key used to provide high level of 
security for encrypting and decrypting data) and saves it to a file named "keypair.pem" using openssl command.

## openssl rsa -in keypair.pem -pubout -out public.pem
- This command takes the privbate key stored in "keypair.pem", extracts the corresponding public key,
and saves it to a file named "public.pem" using openssl command.

## openssl pkcs8 -topk8 -inform PEM -outform PEM -nocrypt -in keypair.pem -out private.pem
- This command converts the private key stored in "keypair.pem" from  PEM format to PKCS8(widely used
standard for encoding private keys).

