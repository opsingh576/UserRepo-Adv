package com.hunger.saviour.portal.apis;

import com.hunger.saviour.portal.dtos.LoginRequestDTO;
import com.hunger.saviour.portal.dtos.SignUpRequestDTO;
import com.hunger.saviour.portal.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("auth")
@RequiredArgsConstructor
public class AuthAPI {

    private final UserService userService;

    @PostMapping("/login")
    public String login(@RequestBody LoginRequestDTO loginRequestDTO){
        return null;
    }

    @PostMapping("/signup")
    public ResponseEntity<String> signUp(@RequestBody SignUpRequestDTO signUpRequestDTO){
        return new ResponseEntity<>(userService.signUp(signUpRequestDTO), HttpStatus.CREATED);
    }
}
