package com.hunger.saviour.portal.services;

import com.hunger.saviour.portal.dtos.SignUpRequestDTO;
import com.hunger.saviour.portal.entities.RoleEntity;
import com.hunger.saviour.portal.entities.UserEntity;
import com.hunger.saviour.portal.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public String signUp(SignUpRequestDTO signUpRequestDTO) {
        UserEntity userEntity = UserEntity.builder()
                .username(signUpRequestDTO.getUsername())
                .password(passwordEncoder.encode(signUpRequestDTO.getPassword()))
                .roles(List.of(new RoleEntity("Admin")))
                .mobileNumber(signUpRequestDTO.getMobileNumber())
                .build();
        userRepository.save(userEntity);
        return "User Created successfully";
    }
}
