package com.product.product_service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.product_service.controller.ProductController;
import com.product.product_service.dto.ProductRequest;
import com.product.product_service.dto.ProductResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductServiceControllerTest {

    @InjectMocks
    ProductController productController;

    @Autowired
    MockMvc mockMvc;

    ProductRequest productRequest;
    List<ProductResponse> productResponseList = new ArrayList<>();
    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        ProductRequest.builder().name("iphone 14").description("iphone 14").price(14000).build();
        ProductResponse productResponse = new ProductResponse();
        productResponse.setName("iphone 14");
        productResponse.setDescription("iphone 14");
        productResponse.setPrice(14000);
        productResponseList.add(productResponse);
    }

    @Test
    public void testCreateProduct() throws Exception {
        String productJson = objectMapper.writeValueAsString(productRequest);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/product")
                .contentType("application/json").content(productJson)
                .accept(String.valueOf(HttpStatus.CREATED)));

    }

    @Test
    public void testGetAllProduct() throws Exception {
        String productJson = objectMapper.writeValueAsString(productRequest);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/product")
                .contentType("application/json")
                .accept(String.valueOf(HttpStatus.OK)));

    }

}
