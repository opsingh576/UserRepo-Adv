package com.product.product_service.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.product_service.dto.ProductRequest;
import com.product.product_service.dto.ProductResponse;
import com.product.product_service.model.Product;
import com.product.product_service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;
    public void createProduct(ProductRequest productRequest) {
        ObjectMapper objectMapper = new ObjectMapper();
        Product product = objectMapper.convertValue(productRequest, Product.class);
        productRepository.save(product);
    }

    public List<ProductResponse> getAllProducts() {
      List<Product> products =  productRepository.findAll();
      return products.stream().map(product->new ProductResponse(product.getId(), product.getName(), product.getDescription(), product.getPrice())).collect(Collectors.toList());
    }


}
