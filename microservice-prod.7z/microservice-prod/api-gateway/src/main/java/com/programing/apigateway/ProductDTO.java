package com.programing.apigateway;

public record ProductDTO(int id, String name){
}
