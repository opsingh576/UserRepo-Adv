package com.programing.apigateway;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Test {
    public static void  main(String[] args)
    {
        List<String> list = Arrays.asList("springboot", "microservices", "java");
    list.parallelStream().flatMap(s1->s1.chars().mapToObj(c->(char)c)).collect(Collectors.groupingBy(w->w, Collectors.counting())).entrySet().stream()
                .forEach(i->System.out.println(i.getKey()+" "+i.getValue()));

        String str = "Hello World";

        //DLROw OLLEh


     String rev = IntStream.range(0, str.length())
                        .mapToObj(c->convetCaseChar(str, c))
                        .map(String::valueOf).collect(Collectors.joining(" "));
System.out.println(rev);
    }

    public static char convetCaseChar(String word, int c)
    {
        char ch = word.charAt(word.length() - 1 - c); // reverse index
        return Character.isUpperCase(ch)
                ? Character.toLowerCase(ch)
                : Character.toUpperCase(ch);
    }
}
