package com.program.order_service.service;

import com.program.order_service.dto.InventoryResponse;
import com.program.order_service.dto.OrderLineItemsRequest;
import com.program.order_service.dto.OrderRequest;
import com.program.order_service.model.Order;
import com.program.order_service.model.OrderLineItems;
import com.program.order_service.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;

    private final WebClient.Builder webClientBuilder;

    public void placeOrder(OrderRequest orderRequest) {
        Order order = new Order();
        order.setOrderNumber(UUID.randomUUID().toString());
        List<OrderLineItems> orderLineItemsList = orderRequest.getOrderLineItemsRequestList().stream().map(orderLineItemsRequest->mapToDto(orderLineItemsRequest))
                .collect(Collectors.toList());
        order.setOrderLineItemsList(orderLineItemsList);
        //call inventory service, and place the order if product is in stock
       List<String> skuCodes = order.getOrderLineItemsList().stream().map(OrderLineItems::getSkuCode).toList();
      List<InventoryResponse> result = webClientBuilder.build().get().uri("http://inventory-service/api/inventory",
               uriBuilder -> uriBuilder.queryParam("skuCode", skuCodes).build())
               .retrieve().bodyToMono(new ParameterizedTypeReference<List<InventoryResponse>>() {}).block();
        result.stream().forEach(inventoryResponse -> System.out.println("skucode"+ inventoryResponse.getSkuCode()));
       if(!result.isEmpty()) {
           boolean allProductsInStock = result.stream().allMatch(InventoryResponse::isInStock);
           if (allProductsInStock) {
               orderRepository.save(order);
           } else {
               throw new IllegalStateException("Product is Not available in stock, pLs try again later ");
           }
       }
       else {
           throw new IllegalStateException("Product is Not available in stock, pLs try again later ");
       }
    }

    public OrderLineItems mapToDto(OrderLineItemsRequest orderLineItemsRequest) {
       return new OrderLineItems(orderLineItemsRequest.getId(),
                orderLineItemsRequest.getSkuCode(), orderLineItemsRequest.getPrice(),
                orderLineItemsRequest.getQuantity());
    }
}
