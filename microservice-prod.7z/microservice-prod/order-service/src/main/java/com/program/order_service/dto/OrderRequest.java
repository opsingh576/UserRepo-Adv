package com.program.order_service.dto;

import com.program.order_service.model.OrderLineItems;
import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderRequest {
    private Long id;
    private String orderNumber;
    private List<OrderLineItemsRequest> orderLineItemsRequestList;
}
