package com.hunger.saviour.portal.services;

import com.hunger.saviour.portal.dtos.RestaurantDTO;
import com.hunger.saviour.portal.entities.RestaurantEntity;
import org.springframework.data.domain.Page;

import java.util.List;

public interface RestaurantService {
    Page<RestaurantEntity> getRestaurants(int pageNumber, int pageSize);
    List<RestaurantDTO> getAllRestaurants();
}
